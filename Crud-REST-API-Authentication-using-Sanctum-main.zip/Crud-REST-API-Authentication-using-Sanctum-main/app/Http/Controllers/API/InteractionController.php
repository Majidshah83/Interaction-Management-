<?php


namespace App\Http\Controllers\API;
use App\Models\Interaction;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;


class InteractionController extends Controller
{
    public function index()
    {
        return Interaction::all();
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'label' => 'required',
            'type' => 'required',
        ]);

        $interaction = Interaction::create($validatedData);

        return response()->json($interaction, 201);
    }

    public function show($id)
    {
        return Interaction::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'label' => 'required',
            'type' => 'required',
        ]);

        $interaction = Interaction::findOrFail($id);
        $interaction->update($validatedData);

        return response()->json($interaction, 200);
    }

    public function destroy($id)
    {
        $interaction = Interaction::findOrFail($id);
        $interaction->delete();

        return response()->json(null, 204);
    }
}
